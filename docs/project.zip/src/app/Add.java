package app;

public class Add {
  private int a;
  private int b;

  public Add(int a, int b) {
    this.a = a;
    this.b = b;
  }

  public int run() {
    // TODO: Implement the addition of a and b.
    return -1;
  }
}
