package app;

public class App {
  private static void print() {
    // TODO: Print out your name.
    System.out.println("Hello, <your name here>!");
  }

  public static void main(String[] args) throws Exception {
    App.print();

    Add adder = new Add(4, 5);
    System.out.println(adder.run());
  }
}
