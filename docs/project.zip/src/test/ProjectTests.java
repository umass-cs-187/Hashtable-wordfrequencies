package test;

import static org.junit.Assert.assertTrue;


import org.junit.Before;
import org.junit.Test;

// these are the same as public tests
public class ProjectTests {

  @Before
  public void before() {
    // Before each test.
  }

  // These tests are public tests.
  @Test(timeout = 3000)
  public void testPublicExampleOne() {
    assertTrue(true);
  }

}
